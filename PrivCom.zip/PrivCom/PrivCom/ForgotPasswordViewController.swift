//
//  ForgotPasswordViewController.swift
//  PrivCom
//
//  Created by Devon Griffith on 2017-04-13.
//  Copyright © 2017 Squid Inc. All rights reserved.
//

import Foundation
import Cocoa
import AppKit



class ForgotPasswordViewController: NSViewController {
    
    
    
    
    func displayAlert(title: String, userMessage: String){
        let myPopup: NSAlert = NSAlert()
        myPopup.messageText = title
        myPopup.informativeText = userMessage
        myPopup.alertStyle = NSAlertStyle.warning
        myPopup.addButton(withTitle: "OK")
        
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }
    
    override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
}
