//
//  SignupViewController.swift
//  PrivCom
//
//  Created by Devon Griffith on 2017-04-13.
//  Copyright © 2017 Squid Inc. All rights reserved.
//

import Foundation
import Cocoa
import AppKit

class SignupViewController: NSViewController {
    
    /*
    func displayAlert(title: String, userMessage: String){
        let myPopup: NSAlert = NSAlert()
        myPopup.messageText = title
        myPopup.informativeText = userMessage
        myPopup.alertStyle = NSAlertStyle.warning
        myPopup.addButton(withTitle: "OK")
        
    }
     */
    
    //let URL_PrivCom = "http://192.168.2.208/MyWebService/api/validateUsers.php" // .php web server URL goes here
    
    
    @IBOutlet weak var usernameTextField: NSTextField!
    @IBOutlet weak var passwordTextField: NSSecureTextField!
    @IBOutlet weak var passwordVerTextField: NSSecureTextField!
    @IBOutlet weak var firstNameTextField: NSTextField!
    @IBOutlet weak var lastNameTextField: NSTextField!
    @IBOutlet weak var emailTextField: NSTextField!
    @IBOutlet weak var emailVerTextField: NSTextField!
 
    
    @IBAction func signupButton(_ sender: Any){
        print("Stuff")
        /*
        //Verify against SQL server (PHP), move to next view
        
        //created NSURL
        let requestURL = NSURL(string: URL_PrivCom)
        
        //creating NSMutableURLRequest
        let request = NSMutableURLRequest(url: requestURL as! URL)
        
        //setting the method to POST
        request.httpMethod = "POST"
        
        //getting user information
        let username = usernameTextField.stringValue
        let password = passwordTextField.stringValue
        let passwordVer = passwordVerTextField.stringValue
        let firstName = firstNameTextField.stringValue
        let lastName = lastNameTextField.stringValue
        let email = emailTextField.stringValue
        let emailVer = emailVerTextField.stringValue
        
        //checking for empty fields
        if (username.isEmpty || password.isEmpty || passwordVer.isEmpty || firstName.isEmpty || lastName.isEmpty || email.isEmpty || emailVer.isEmpty){
            
            //display alert message
            displayAlert(title: "Error", userMessage: "All fields are required")
            return
        }
        
        //check passwords match
        if (password != passwordVer){
            
            //display alert message
            displayAlert(title: "Error", userMessage: "Passwords do not match")
            return
        }
        
        //check emails match
        if (email != emailVer){
        
            //display alert message
            displayAlert(title: "Error", userMessage: "Emails do not match")
            return
        }
        
        
        //creating the post parameters by concatonating the keys and values from text field
        let postParameters = "userID=" + username + "&password=" + password + "userEmail" + email + "firstName" + firstName + "lastName" + lastName
        
        //adding the parameters to the request body
        request.httpBody = postParameters.data(using: String.Encoding.utf8)
        
        //creating a task to send the request to the web server
        let task = URLSession.shared.dataTask(with: request as URLRequest){
            data, response, error in
            
            if error != nil{
                print("error is \(error)")
                return;
            }
            
            //parsing the response
            do {
                //converting the response to NSDictionary
                let myJSON = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                //parsing the JSON
                if let parseJSON = myJSON {
                    //creating a string
                    var msg : String!
                    
                    //getting the JSON response
                    msg = parseJSON["Message"] as! String?
                    
                    //printing the response
                    print(msg)
                }
            } catch {
                print(error)
            }
        }
        //executing the task
        task.resume()*/
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    /*
    override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
 */
    
    
//    override func prepare(for segue: NSStoryboardSegue, sender: Any?) {
//        if segue.identifier == "NewEvent" {
//            let nextVC = segue.destination as? LoggedViewController
//        }
//    }
    
    
    
    
}
