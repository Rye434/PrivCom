//
//  ViewController.swift
//  PrivCom
//
//  Created by Devon Griffith on 2017-04-07.
//  Copyright © 2017 Squid Inc. All rights reserved.
//

import Cocoa
import AppKit


class ViewController: NSViewController {
    
    //alert function
    func displayAlert(title: String, userMessage: String){
        let myPopup: NSAlert = NSAlert()
        myPopup.messageText = title
        myPopup.informativeText = userMessage
        myPopup.alertStyle = NSAlertStyle.warning
        myPopup.addButton(withTitle: "OK")
        
    }
    
    let URL_PrivCom = "http://192.168.2.208/MyWebService/api/validateUsers.php" // .php web server URL goes here
    
    @IBOutlet weak var loginButton: NSButton!
    @IBOutlet weak var usernameTextField: NSTextField!
    @IBOutlet weak var passwordTextField: NSSecureTextField!
    @IBOutlet weak var forgotPasswordButton: NSButton!
    @IBOutlet weak var signupButton: NSButton!
    
    
    @IBAction func loginButton(_ sender: NSButton) {
        //Verify against SQL server (PHP), move to next view
        
        //created NSURL
        let requestURL = NSURL(string: URL_PrivCom)
        
        //creating NSMutableURLRequest
        let request = NSMutableURLRequest(url: requestURL as! URL)
        
        //setting the method to POST
        request.httpMethod = "POST"
        
        //getting username and password
        let username = usernameTextField.stringValue
        let password = passwordTextField.stringValue
        
        //catch empty fields
        if (username.isEmpty || password.isEmpty){
            displayAlert(title: "Error", userMessage: "One or more fields are empty")
        }
        
        //creating the post parameters by concatonating the keys and values from text field 
        let postParameters = "userID=" + username + "&password=" + password
        
        //adding the parameters to the request body
        request.httpBody = postParameters.data(using: String.Encoding.utf8)
        
        //creating a tast to send the request to the web server
        let task = URLSession.shared.dataTask(with: request as URLRequest){
            data, response, error in
            
            if error != nil{
                print("error is \(error)")
                return;
            }
            
            //parsing the response
            do {
                //converting the response to NSDictionary
                let myJSON = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                
                //parsing the JSON
                if let parseJSON = myJSON {
                    //creating a string
                    var msg : String!
                    
                    //getting the JSON response
                    msg = parseJSON["Message"] as! String?
                    
                    //printing the response
                    print(msg)
                }
            } catch {
                print(error)
            }
        }
        //executing the task
        task.resume()
    }
    
    @IBAction func signupButton(_ sender: Any) {
    }
    
    @IBAction func forgotPasswordButton(_ sender: Any) {
    }
 
    @IBAction func returnHomeButton(_ sender: Any) {
    }
    
 
 
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }


}




