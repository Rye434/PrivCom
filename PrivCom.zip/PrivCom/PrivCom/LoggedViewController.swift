//
//  LoggedViewController.swift
//  PrivCom
//
//  Created by Devon Griffith on 2017-04-16.
//  Copyright © 2017 Squid Inc. All rights reserved.
//

import Foundation
import Cocoa
import AppKit

class LoggedViewController: NSViewController {


    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
    
    
}
