//
//  CredentialsModel.swift
//  PrivCom
//
//  Created by Devon Griffith on 2017-04-08.
//  Copyright © 2017 Squid Inc. All rights reserved.
//

import Foundation

class CredentialsModel: NSObject {
    
    //properties
    
    var name: String?
    var password: String?
    
    
    //empty constructor
    
    override init()
    {
        
    }
    
    //construct with @name, and @password parameters
    
    init(name: String, password: String) {
        
        self.name = name
        self.password = password

    }
    
    
    //prints object's current state >>> TO BE REMOVED, VERIFY AGAINST SQL TABLE
    
    override var description: String {
        return "Name: \(name), Password: \(password)"
        
    }
    
    
}
