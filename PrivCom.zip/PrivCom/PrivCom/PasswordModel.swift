//
//  PasswordModel.swift
//  PrivCom
//
//  Created by Devon Griffith on 2017-04-08.
//  Copyright © 2017 Squid Inc. All rights reserved.
//

import Foundation
